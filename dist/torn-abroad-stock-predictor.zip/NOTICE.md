# Attribution & Contributors

All significant contributions to this project should be listed here.  
Automatically preserve your copyright header in each file.

– 2025‑05‑09: MrChurchh [3654415] <0xxzerocoolxx0@gmail.com> — initial version
